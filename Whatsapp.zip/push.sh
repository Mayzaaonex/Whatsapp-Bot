#!/bin/bash

# ============================================================
# Auto Push to GitHub
# Repo: https://github.com/Mayzaaonex/Whatsapp-Bot
# Usage: bash push.sh "commit message"
# ============================================================

set -e

# ==== CONFIG ====
REPO_URL="https://github.com/Mayzaaonex/Whatsapp-Bot.git"
BRANCH="main"

# ==== COMMIT MESSAGE ====
MSG="${1:-update: $(date +'%d/%m/%Y %H:%M:%S')}"

echo "════════════════════════════════════════"
echo "📦 Auto Push to GitHub"
echo "════════════════════════════════════════"
echo "📁 Repo    : $REPO_URL"
echo "🌿 Branch  : $BRANCH"
echo "📝 Message : $MSG"
echo "════════════════════════════════════════"
echo ""

# ==== INIT REPO (kalau belum ada .git) ====
if [ ! -d ".git" ]; then
  echo "🔧 Repo belum di-init, init dulu..."

  # Bikin README kalau belum ada
  if [ ! -f "README.md" ]; then
    echo "# Whatsapp-Bot" > README.md
    echo "🤖 Whatsapp Bot using zapo-js" >> README.md
  fi

  git init
  git add README.md
  git commit -m "first commit"
  git branch -M main
  git remote add origin "$REPO_URL"
  echo "✅ Repo berhasil di-init"
  echo ""
fi

# ==== PASTIIN REMOTE ORIGIN ====
if ! git remote get-url origin > /dev/null 2>&1; then
  echo "🔧 Remote origin belum ada, tambahin..."
  git remote add origin "$REPO_URL"
  echo "✅ Remote origin ditambah"
  echo ""
fi

# ==== ADD SEMUA (kecuali .gitignore) ====
echo "📂 Adding files..."
git add -A

# ==== CEK ADA PERUBAHAN ====
if git diff --cached --quiet; then
  echo "⚠️  Gak ada perubahan. Skip commit."
  echo ""

  # Tapi tetep push (kalau ada commit lama yang belum ke-push)
  echo "🔍 Cek commit yang belum ke-push..."
  if git log origin/$BRANCH..$BRANCH > /dev/null 2>&1; then
    echo "📤 Ada commit yang belum ke-push, push sekarang..."
    git push origin $BRANCH --force
    echo "✅ Push berhasil!"
  else
    echo "✅ Semua commit udah ke-push."
  fi
  exit 0
fi

# ==== COMMIT ====
echo "💾 Committing..."
git commit -m "$MSG" || {
  echo "❌ Gagal commit!"
  exit 1
}

# ==== PUSH (FORCE) ====
echo ""
echo "📤 Pushing to GitHub (force)..."
git push origin $BRANCH --force || {
  echo "❌ Gagal push! Cek koneksi internet / token GitHub."
  exit 1
}

echo ""
echo "════════════════════════════════════════"
echo "✅ Berhasil push ke GitHub!"
echo "════════════════════════════════════════"
echo "🔗 $REPO_URL"
echo "════════════════════════════════════════"